tvbox & diyp & kodi 配置文件。所有资源均来自于各路大神无私分享，如有侵权，请联系删除。
1. tvbox配置：
   
   （1）0820.json  较全面的源，jar的来源于WEWA（饭太硬）的jar包；
   
   （2）0820.txt  精简的源，jar的来源唐三的jar包；
   
   （3）0821.json  jar的来源于俊于的jar包，在原有俊于配置的基础上添加了一些XBiu、XBiuBiu、XF规则的源；
   
   （4）0827.json  完全来源于fongmi的jar包和配置；
   
   （5）0828.json  完全来源于唐三的jar包和配置；
   
   （6）0829.json  完全来源于俊于的jar包和配置；
   
   （7）js.json  资源来源于watson chen收集整理的道长drpy(js)资源；
   
   （8）xBPQ.json  纯xBPQ源，jar包和配置来源于菜妮丝；
   
   （9）1.json  测试用的配置，慎用；
   
   （10）9918.json  nsfw的源，慎用，jar的来源fongmi的jar包。
   
   APP推荐使用q215613905版本（项目地址：https://github.com/q215613905/TVBoxOS ）和FongMi（项目地址：https://github.com/FongMi/TV ）版本，[DRPY]数据源适用于q215613905版，直播多线路适用于FongMi版。
2. diyp配置：

   （1）list.txt  线路一；
   
   （2）iptv.txt  线路二；
   
   （3）live.txt  线路三。
   
   以上配置原名称为绿色直播源；****x.txt为nsfw直播源，慎用；****xx.txt为测试用直播源，慎用。
3. kodi插件及配置：

   （1）plugin.video.ysdq.zip  kodi插件 影视大全by小明；
   
   （2）plugin.video.ysdqg.zip  kodi插件 影视大全（改）by霜辉月明;

   （3）YSDQ.json  影视大全（改）的配置文件;
   
   （4）list.m3u  PVR IPTV Simple 直播源，绿色源;
   
   （5）listx.m3u  PVR IPTV Simple 直播源，nsfw源，慎用。
4. TVBox各路大佬配置（排名不分先后）：
    
   （1）唐三：https://hutool.ml/tang
   
   （2）Fongmi：https://raw.fastgit.org/FongMi/CatVodSpider/main/json/config.json
   
   （3）俊于：http://home.jundie.top:81/top98.json
   
   （4）饭太硬：http://饭太硬.ga/x/o.json
   
   （5）霜辉月明py：https://ghproxy.com/raw.githubusercontent.com/lm317379829/PyramidStore/pyramid/py.json
   
   （6）小雅dr：http://drpy.site/js1
   
   （7）菜妮丝：https://tvbox.cainisi.cf
   
   （8）神器：https://神器每日推送.tk/pz.json
   
   （9）巧技：http://pandown.pro/tvbox/tvbox.json
   
   （10）刚刚：http://刚刚.live/猫
 
   （11）吾爱有三：http://52bsj.vip:98/0805
   
   （12）潇洒：https://download.kstore.space/download/2863/01.txt
   
   （13）佰欣园：https://ghproxy.com/https://raw.githubusercontent.com/chengxueli818913/maoTV/main/44.txt   
   
   （14）胖虎：https://notabug.org/imbig66/tv-spider-man/raw/master/配置/0801.json
    
   （15）云星日记：https://maoyingshi.cc/tiaoshizhushou/1.txt
                  
   （16）Yoursmile7：https://agit.ai/Yoursmile7/TVBox/raw/branch/master/XC.json
   
   （17）BOX：http://52bsj.vip:81/api/v3/file/get/29899/box2.json?sign=3cVyKZQr3lFAwdB3HK-A7h33e0MnmG6lLB9oWlvSNnM%3D%3A0
   
   （18）哔哩学习：http://52bsj.vip:81/api/v3/file/get/41063/bili.json?sign=TxuApYZt6bNl9TzI7vObItW34UnATQ4RQxABAEwHst4%3D%3A0
   
   （19）UndCover：https://raw.githubusercontent.com/UndCover/PyramidStore/main/py.json
   
   （20）木极：https://pan.tenire.com/down.php/2664dabf44e1b55919f481903a178cba.txt  
   
   （21）Ray：https://dxawi.github.io/0/0.json
   
   （22）甜蜜：https://kebedd69.github.io/TVbox-interface/py甜蜜.json
   
   （23）52bsj：http://52bsj.vip:81/api/v3/file/get/29899/box2.json?sign=3cVyKZQr3lFAwdB3HK-A7h33e0MnmG6lLB9oWlvSNnM%3D%3A0
   
   （24）肥猫：http://我不是.肥猫.love:63
5. 随机轮换壁纸：

   （1）https://bing.img.run/rand.php
   
   （2）http://www.kf666888.cn/api/tvbox/img
   
   （3）https://picsum.photos/1280/720/?blur=10
      
   （4）http://刚刚.live/图 
  
   （5）http://饭太硬.ga/深色壁纸/api.php
 
   （6）https://www.dmoe.cc/random.php
      
   （7）https://api.btstu.cn/sjbz/zsy.php
      
   （8）https://api.btstu.cn/sjbz/?lx=dongman
      
   （9）http://api.btstu.cn/sjbz/?lx=meizi
      
   （10）http://api.btstu.cn/sjbz/?lx=suiji
   
   （11）https://pictures.catvod.eu.org/

如果喜欢，请复刻自用，切勿传播。谢谢！

尽自己所能更新，不保证配置的有效性和时效性。
   
