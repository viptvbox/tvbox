muban.首图2.推荐 = 'ul.stui-vodlist.clearfix;li;a&&title;.lazyload&&data-original;.pic-text&&Text;a&&href'; 
muban.首图2.二级.content = '.stui-pannel_bd p:eq(0)';
muban.首图2.二级.desc = ';;.stui-content__detail p:eq(0);.stui-content__detail p:eq(1);.stui-content__detail p:eq(2)'
muban.首图2.二级.tabs = '.stui-pannel__head.bottom-line.active.clearfix h3';
var rule = Object.assign(muban.首图2,{
title:'双十电影',
host:'https://www.1010dy3.com',
url:'/show/fyclass/page/fypage/',
searchUrl:'/search/page/fypage/wd/**/',
class_name:'电影&电视剧&动漫&综艺',
class_url:'1&2&3&4',
tab_exclude:'为你|榜单',
搜索:'ul.stui-vodlist__media&&li;a&&title;.lazyload&&data-original;.text-muted&&Text;a&&href;.text-muted:eq(-1)&&Text',
});
